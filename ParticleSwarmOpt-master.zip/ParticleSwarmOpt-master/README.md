# ParticleSwarmOpt
A C++ Implementation for Particle Swarm Optimization.
(Still under development)
